use ClientDB 
CREATE TABLE Client_A_Contacts 
( 
   first_name varchar(100), 
   last_name varchar(100),
   city varchar(100),
   county varchar(100),
   zip varchar(100),
   officePhone varchar(100),
   mobilePhone varchar(100), 
)

